import os
import plugin

plugin_class="ctrain"


class ctrain(plugin.AriadneOp):
    name="ctrain"

    def run(self, args):
        os.system("mkdir -p Workspace")
        os.system("$PYTHON $ROOT/util/create_input_datasets.py -i Data/ac3train/input -l Data/ac3train/labels -o Workspace/train_data.h5")
        os.system("$PYTHON $ROOT/util/create_membrane_training.py -i Workspace/train_data.h5 -p 5 -n 10")
