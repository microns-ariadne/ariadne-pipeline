import os
import plugin

plugin_class="neuroproof"


class neuroproof(plugin.AriadneMLOp):
    name="neuroproof"


    def train_depends(self):
        d=[]

        d.append(plugin.DependencyContainer("watersheds", {}))
        d.append(plugin.DependencyContainer("prepneuroproof", {}))
        return d

    def train(self, args):
        os.system("neuroproof_graph_learn Workspace/np_train_watersheds.h5 Workspace/np_train_probabilities.h5 Workspace/np_train_groundtruth.h5 --use_mito 0 --classifier-name Workspace/neuroproof_classifier.xml --num-iterations 1")

        os.system("neuroproof_graph_predict Workspace/np_train_watersheds.h5 Workspace/np_train_probabilities.h5 Workspace/neuroproof_classifier.xml --output-file Workspace/np_train_merged.h5")


    def depends(self):
        d=[]

        d.append(plugin.DependencyContainer("watersheds", {"data": "test_data.h5", "num": "250"}))
        d.append(plugin.DependencyContainer("prepneuroproof", {"traintest": "test"}))


    def run(self, args):
        os.system("neuroproof_graph_predict Workspace/np_test_watersheds.h5 Workspace/np_test_probabilities.h5 Workspace/neuroproof_classifier.xml --output-file Workspace/np_test_merged.h5")
