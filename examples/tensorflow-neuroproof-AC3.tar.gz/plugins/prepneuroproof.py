import os
import plugin

plugin_class="prepneuroproof"


class prepneuroproof(plugin.AriadneOp):
    name="prepneuroproof"


    def run(self, args):
        traintest="test"

        try:
            traintest=args['traintest']
        except:
            pass
        os.system("$PYTHON $ROOT/util/prepare_neuroproof_training.py -i Workspace/%s_data.h5 -w Workspace/np_%s_watersheds.h5 -p Workspace/np_%s_probabilities.h5 -g Workspace/np_%s_groundtruth.h5" % (traintest, traintest, traintest, traintest))
