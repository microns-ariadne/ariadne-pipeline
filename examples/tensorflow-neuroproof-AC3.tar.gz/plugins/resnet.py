import os
import plugin

plugin_class="resnet"


class resnet(plugin.AriadneMLOp):
    name="resnet"


    def depends(self):
        d=[]

        d.append(plugin.DependencyContainer("mkdir", {"dirname": "Workspace/checkpoints"}))
        d.append(plugin.DependencyContainer("mkdir", {"dirname": "Workspace/summaries"}))

        return d


    def get_train_arg_names(self):
        return ['numiters', 'learnrate', 'data']


    def train(self, args):
        numiters=1000
        learnrate=0.1
        data="train-data.h5"

        try:
            numiters=int(args['numiters'])
            learnrate=float(args['learnrate'])
            data=args['data']
        except:
            pass

        os.system("$PYTHON $ROOT/membrane_classifier/train_resnet.py --learning_rate %f --summary_dir Workspace/summaries --checkpoint_dir Workspace/checkpoints --hdf5 Workspace/train_data.h5 --batch_size 3 --num_modules $RESNET_COUNT --iterations %d" % (learnrate, numiters))


    def get_arg_names(self):
        return ['data']


    def run(self, args):
        data="train_data.h5"

        try:
            data=args['data']
        except:
            pass

        os.system("$PYTHON $ROOT/membrane_classifier/classify_resnet.py --num_modules $RESNET_COUNT --checkpoint_dir Workspace/checkpoints --hdf5 Workspace/%s" % data)
