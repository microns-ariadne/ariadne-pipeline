import os
import plugin

plugin_class="watersheds"


class watersheds(plugin.AriadneOp):
    name="watersheds"


    def run(self, args):
        data="Workspace/test_data.h5"
        num=250

        try:
            data=args['data']
            num=int(args['num'])
        except:
            pass

        os.system("$PYTHON $ROOT/util/create_watersheds.py -i Workspace/%s -s %d" % (data, num))
