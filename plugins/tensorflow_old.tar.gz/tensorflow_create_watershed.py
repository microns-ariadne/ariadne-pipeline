# tensorflow_create_watershed.py -- Runs watershed task.

plugin_class="tensorflow_create_watershed"
