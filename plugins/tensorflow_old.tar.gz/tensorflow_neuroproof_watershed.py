# tensorflow_neuroproof_watershed.py -- Should probably be merged with the other watershed plugin with args.
import os
import plugin

plugin_class="tensorflow_neuroproof_watershed"


class tensorflow_neuroproof_watershed(plugin.AriadneOp):
    
